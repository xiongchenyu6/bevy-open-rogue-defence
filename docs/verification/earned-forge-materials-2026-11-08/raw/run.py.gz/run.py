from pathlib import Path
import subprocess,json,hashlib,shutil,time
r=Path.cwd();p=r/'target/verification/earned-forge-materials-r7-2026-11-08';out=p/'forge';out.mkdir();h=out/'harness-source';h.mkdir();state=out/'state';state.mkdir();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
artifact=json.loads((r/'target/verification/forge-package-2026-11-08/artifact.json').read_text());package=r/artifact['package_directory'];image=json.loads((r/'target/verification/forge-package-2026-11-08/runtime-image.json').read_text())['id']
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha((package/'rogue_commander').read_bytes())==artifact['binary_sha256']
for row in json.loads((package/'package-manifest.json').read_text())['files']:assert sha((package/row['file']).read_bytes())==row['sha256']
source=r/'docs/verification/earned-equipment-2026-10-09/initial-campaign.save';initial=source.read_bytes();assert sha(initial)=='da5bf0a9ca3f4032a265425f9989bda292d8c0c2622848157df6d2c0223ba825';(state/'campaign.save').write_bytes(initial);(p/'initial-campaign.save').write_bytes(initial)
(out/'initial-save-provenance.json').write_text(json.dumps({'source':str(source.relative_to(r)),'sha256':sha(initial),'copied_bytes_unchanged':True},indent=2)+'\n')
files={}
for name in ['forge_runtime.py','forge_restart_runtime.py','forge_refresh.py','campaign_equipment_runtime.py','campaign_runtime.py','smoke_runtime.py']:
 data=subprocess.check_output(['git','show',commit+':tools/desktop/'+name]);assert data==(r/'tools/desktop'/name).read_bytes();(h/name).write_bytes(data);files[name]=sha(data)
(out/'harness-snapshot.json').write_text(json.dumps({'harness_commit':commit,'package_commit':artifact['source_commit'],'files':files,'scope':'Public X11 UI, immutable package, copied real earned profile, first chapter at actual1x, natural stock and kill currency. No game-state injection.'},indent=2)+'\n')
def run(label,cmd,timeout):
 start=time.monotonic()
 try:
  with (p/(label+'.log')).open('w') as log:res=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
  receipt={'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start}
 except subprocess.TimeoutExpired:receipt={'command':cmd,'timeout':True,'elapsed':time.monotonic()-start}
 finally:subprocess.run(['docker','stop','-t','15','rogue-earned-forge-materials-r7-'+label+'-nov8'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 (p/(label+'-process.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,receipt,flush=True);assert receipt.get('returncode')==0,label
base=['docker','run','--rm','--network','none','--mount',f'type=bind,src={package},dst=/game,readonly','--mount',f'type=bind,src={h},dst=/harness,readonly','--env','PACKAGE_COMMIT='+artifact['source_commit'],'--workdir','/tmp']
run('forge',base+['--name','rogue-earned-forge-materials-r7-forge-nov8','--mount',f'type=bind,src={out},dst=/verify',image,'python3','/harness/forge_runtime.py'],4800)
restart=p/'restart';restart.mkdir()
run('restart',base+['--name','rogue-earned-forge-materials-r7-restart-nov8','--mount',f'type=bind,src={restart},dst=/verify','--mount',f'type=bind,src={state},dst=/earned-state','--mount',f'type=bind,src={out},dst=/previous-proof,readonly',image,'python3','/harness/forge_restart_runtime.py'],240)
assert (state/'campaign.save').read_bytes()==initial;print('EARNED FORGE AND SAME STATE RESTART PASS',flush=True)
