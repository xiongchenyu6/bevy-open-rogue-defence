import pathlib,subprocess,hashlib,json,os,time
r=pathlib.Path.cwd();out=r/'target/verification/current-ur-branches-2026-11-08';origin=r/'target/verification/fallen-camera-2026-11-08/after';exe=origin/'capture';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(exe)==(origin/'capture-sha256.txt').read_text().strip()
inputs=json.loads((origin/'inputs.json').read_text());assert all(sha(r/n)==v for n,v in inputs.items())
assets={str(p.relative_to(r)):sha(p) for p in sorted((r/'assets').rglob('*')) if p.is_file()};host=pathlib.Path.home()/'.config/rogue-commander/campaign-v1.save';before=sha(host)
(out/'provenance.json').write_text(json.dumps(dict(source='df51a6c',binary=sha(exe),inputs=inputs,assets=assets,host_before=before,controlled_prerequisites='Mastery rank5 level50 gold50000; actual paid draw and branch choice/runtime'),indent=2)+'\n')
rows=[]
for skill in range(26,30):
 for path in ('surge','control','sustain'):
  case=f'ur{skill}-{path}';p=out/case;p.mkdir();state=p/'state';state.mkdir();env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_')};env.update(XDG_CONFIG_HOME=str(state/'config'),ROGUE_CAMPAIGN_SAVE=str(state/'campaign.save'),ROGUE_AUDIO_SAVE=str(state/'audio.save'),ROGUE_TUTORIAL_SAVE=str(state/'tutorial.save'),ROGUE_COMMANDER_LANG='en',ROGUE_CAPTURE_SAVE_FRAMES='30,60,180,300,399')
  cmd=['nix','develop','--command',str(exe),'frames',str(p/'native'),'400',case,'0xA11CE','1280x720'];start=time.monotonic()
  with (p/'native.log').open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
  receipt=dict(case=case,command=cmd,returncode=result.returncode,elapsed=time.monotonic()-start);(p/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');rows.append(receipt);print(json.dumps(receipt),flush=True)
  assert result.returncode==0,case
assert all(sha(r/n)==v for n,v in inputs.items());assert all(sha(r/n)==v for n,v in assets.items());assert sha(host)==before
(out/'result.json').write_text(json.dumps(dict(cases=rows,host_after=sha(host),inputs_unchanged=True,assets_unchanged=True),indent=2)+'\n')
