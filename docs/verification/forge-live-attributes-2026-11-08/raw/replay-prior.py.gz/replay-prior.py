import json,sys
from pathlib import Path
sys.path.insert(0,'/work/tools/desktop')
from smoke_runtime import ocr_screenshot
from forge_runtime import magic_penetration_from_rows
p=Path('/work/target/verification/earned-forge-materials-r7-2026-11-08/restart/restart-strength.png')
rows=ocr_screenshot(p,None);value,evidence=magic_penetration_from_rows(rows);assert value==0
print(json.dumps({'actual_prior_restart_magic_penetration':value,'evidence':evidence,'all_rows':rows,'scope':'Retrospective prior restart screenshot only, not same-run crafted attributes.'},indent=2))
