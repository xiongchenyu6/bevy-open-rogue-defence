import json,sys
from pathlib import Path
sys.path.insert(0,'/work/tools/desktop')
from smoke_runtime import ocr_screenshot
from campaign_equipment_runtime import choice_pending
p=Path('/work/target/verification/earned-forge-attributes-r9-2026-11-08/forge/current-ui.png');rows=ocr_screenshot(p,None);assert choice_pending(rows)
print(json.dumps({'recognized_choice':True,'all_rows':rows,'scope':'Retrospective pixels only, no input or new live observation.'},indent=2))
