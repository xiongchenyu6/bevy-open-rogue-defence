from pathlib import Path
import os,json,subprocess,time
r=Path.cwd();p=r/'target/verification/ui-layer-2026-11-08';old=r/'target/verification/decision-phase-2026-11-07/after-r3'
for size,lang in [('360x800','zh'),('1280x720','en')]:
 receipt=json.loads((old/('native-'+size+'-'+lang+'-result.json')).read_text());cmd=receipt['command'];cmd[5]=str(p/('native-'+size))
 env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'}
 env.update(EXPECT_FULL_SLOT_VARIETY='1',ROGUE_CAPTURE_VARIETY_SEED='0' if lang=='zh' else '1',ROGUE_CAPTURE_VARIETY_RARITY='Ssr' if lang=='zh' else 'Sr',ROGUE_COMMANDER_LANG=lang,ROGUE_CAPTURE_SAVE_FRAMES='90,95,100,105,110,115,120,125,159,179',VK_ICD_FILENAMES='/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json')
 for k in ['CAMPAIGN','TUTORIAL','AUDIO']:env['ROGUE_'+k+'_SAVE']=str(p/(size+'-'+k+'.txt'))
 with (p/(size+'.log')).open('w') as f:
  start=time.monotonic();res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 (p/(size+'-result.json')).write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start},indent=2))
 print(size,res.returncode,flush=True)
 if res.returncode:break
