from pathlib import Path
import subprocess,json,time,hashlib
r=Path.cwd();p=r/'target/verification/ui-layer-2026-11-08/single-camera';cmd=['nix','develop','--command','cargo','build','--locked','--bin','capture','-j1','--target-dir','target/market-visual','--config','profile.dev.opt-level=0','--config','profile.dev.package."*".opt-level=0','--config','profile.dev.debug=0']
start=time.monotonic()
with (p/'build.log').open('w') as f:res=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(p/'result.json').write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start}))
if res.returncode:raise SystemExit(res.returncode)
import shutil
shutil.copyfile(r/'target/market-visual/debug/capture',p/'capture');(p/'capture').chmod(0o755)
(p/'binary.sha256').write_text(hashlib.sha256((p/'capture').read_bytes()).hexdigest())
script=(p.parent/'run.py').read_text().replace("p=r/'target/verification/ui-layer-2026-11-08'","p=r/'target/verification/ui-layer-2026-11-08/single-camera'").replace("cmd[5]=str(p/('native-'+size))","cmd[3]=str(p/'capture');cmd[5]=str(p/('native-'+size))")
script=script.replace("env.update(EXPECT_FULL_SLOT_VARIETY=","env.update(ROGUE_CAPTURE_UI_SINGLE_CAMERA='1',ROGUE_CAPTURE_UI_LAYERS='1',EXPECT_FULL_SLOT_VARIETY=")
exec(compile(script,'diagnostic-probe','exec'))
