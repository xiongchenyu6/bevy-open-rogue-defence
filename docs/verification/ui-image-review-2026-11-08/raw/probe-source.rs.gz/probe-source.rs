//! Opt-in render-world diagnostics for missing UI layers.
use bevy::{prelude::*, render::{Render, RenderApp, RenderSystems, render_phase::{PhaseItem, ViewSortedRenderPhases}}, ui_render::{ExtractedUiItem, ExtractedUiNodes, UiBatch, TransparentUi, prepare_uinodes}};

pub fn install(app: &mut App) {
    if std::env::var("ROGUE_CAPTURE_UI_LAYERS").as_deref() != Ok("1") {
        return;
    }
    if std::env::var("ROGUE_CAPTURE_UI_SINGLE_CAMERA").as_deref() == Ok("1") {
        app.add_systems(PostStartup, single_camera);
    }
    let render = app.sub_app_mut(RenderApp);
    render.add_systems(Render, extracted.before(prepare_uinodes).in_set(RenderSystems::PrepareBindGroups));
    render.add_systems(Render, prepared.after(RenderSystems::PrepareBindGroups).before(RenderSystems::Render));
}
fn extracted(nodes: Res<ExtractedUiNodes>, phases: Res<ViewSortedRenderPhases<TransparentUi>>, mut frame: Local<u32>) {
    *frame += 1;
    let mismatched = phases.values().flat_map(|phase| phase.items.values()).filter(|item| nodes.uinodes.get(item.index).is_none_or(|node| node.render_entity != item.entity())).count();
    println!("[ui-layers] queued frame={} mismatched_indices={mismatched}", *frame);
    let quads = nodes.uinodes.iter().filter(|node| matches!(node.item, ExtractedUiItem::Node { .. })).count();
    println!("[ui-layers] extracted frame={} nodes={} quads={} glyphs={}", *frame, nodes.uinodes.len(), quads, nodes.glyphs.len());
    if (90..=145).contains(&*frame) {
        for node in &nodes.uinodes {
            if let ExtractedUiItem::Node { rect, color, .. } = &node.item {
                if rect.width() > 250. && rect.height() > 500. {
                    println!("[ui-layers] large frame={} entity={:?} camera={:?} z={} rect={rect:?} color={color:?}", *frame,node.main_entity,node.extracted_camera_entity,node.z_order);
                }
            }
        }
    }
}
fn prepared(phases: Res<ViewSortedRenderPhases<TransparentUi>>, batches: Query<&UiBatch>, mut frame: Local<u32>) {
    *frame += 1;
    let mut items = 0;
    let mut draws = 0;
    let mut missing = 0;
    for phase in phases.values() {
        for item in phase.items.values() {
            items += 1;
            if item.batch_range().is_empty() { continue; }
            draws += 1;
            if batches.get(item.entity()).is_err() { missing += 1; }
        }
    }
    println!("[ui-layers] prepared frame={} items={items} draws={draws} missing_batches={missing}", *frame);
}

fn single_camera(mut commands: Commands, mut cameras: Query<(Entity, Option<&Name>, &mut Camera, Has<Camera3d>)>) {
    for (entity, name, mut camera, is_world) in &mut cameras {
        if name.is_some_and(|name| name.as_str() == "DAMAGE NUMBER CAMERA") {
            camera.is_active = false;
            commands.entity(entity).remove::<IsDefaultUiCamera>();
            println!("[ui-layers] disabled overlay camera");
        } else if is_world {
            commands.entity(entity).insert(IsDefaultUiCamera);
            println!("[ui-layers] world camera owns UI");
        }
    }
}
