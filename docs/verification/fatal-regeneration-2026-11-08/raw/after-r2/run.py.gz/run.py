from pathlib import Path
import subprocess,time,json,hashlib,os
r=Path.cwd();p=r/'target/verification/fatal-regeneration-2026-11-08/after-r2'
inputs={str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [*r.glob('src/**/*.rs'),r/'Cargo.toml',r/'Cargo.lock']}
(p/'inputs.json').write_text(json.dumps(inputs,indent=2))
cmd=['nix','develop','--command','cargo','test','--locked','--release','--lib','production_fatal_boss','-j2','--','--nocapture','--test-threads=1']
start=time.monotonic();env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_')}
with (p/'tests.log').open('w') as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'result.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==digest for f,digest in inputs.items())
assert res.returncode == 0
cmd=['nix','develop','--command','cargo','test','--locked','--release','--lib','-j2','--','--test-threads=1']
start=time.monotonic()
with (p/'library.log').open('w') as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'library-result.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==digest for f,digest in inputs.items())
assert res.returncode == 0
for label,cmd in [
 ('clippy',['nix','develop','--command','cargo','clippy','--locked','--release','--all-targets','-j2','--','-D','warnings']),
 ('sim-build',['nix','develop','--command','cargo','build','--locked','--release','--bin','balance_sim','-j2'])]:
 start=time.monotonic()
 with (p/(label+'.log')).open('w') as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 (p/(label+'-result.json')).write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
 assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==digest for f,digest in inputs.items())
 assert res.returncode == 0,label


assert res.returncode == 0
cmd=['nix','develop','--command','cargo','build','--locked','--bin','capture','-j1','--target-dir','target/market-visual','--config','profile.dev.opt-level=0','--config','profile.dev.package."*".opt-level=0','--config','profile.dev.debug=0']
start=time.monotonic()
with (p/'capture-build.log').open('w') as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'capture-build-result.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
assert res.returncode==0
import shutil
exe=p/'capture';shutil.copy2(r/'target/market-visual/debug/capture',exe)
(p/'capture-sha256.txt').write_text(hashlib.sha256(exe.read_bytes()).hexdigest())
native_env=dict(env,ROGUE_CAPTURE_SAVE_FRAMES='124,149,199,244,319,374,399',ROGUE_COMMANDER_LANG='en')
cmd=['nix','develop','--command',str(exe),'frames',str(p/'native'),'400','gate-revival','0xA11CE','1280x720']
start=time.monotonic()
with (p/'native.log').open('w') as log:res=subprocess.run(cmd,env=native_env,stdout=log,stderr=subprocess.STDOUT)
(p/'native-result.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==digest for f,digest in inputs.items())
assert res.returncode==0
