import pathlib,subprocess,json,os,time,hashlib
r=pathlib.Path.cwd();p=r/'target/verification/x11-background-fix-2026-11-08';state=p/'state';state.mkdir();env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_')};env.update(XDG_CONFIG_HOME=str(state/'config'),ROGUE_CAMPAIGN_SAVE=str(state/'campaign.save'),ROGUE_AUDIO_SAVE=str(state/'audio.save'),ROGUE_TUTORIAL_SAVE=str(state/'tutorial.save'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();host=pathlib.Path.home()/'.config/rogue-commander/campaign-v1.save';before=sha(host)
inputs={str(f.relative_to(r)):sha(f) for f in [*r.glob('src/**/*.rs'),r/'Cargo.toml',r/'Cargo.lock']};(p/'inputs.json').write_text(json.dumps(inputs,indent=2))
commands=[('library',['cargo','test','--locked','--release','--lib','-j2','--','--test-threads=1']),('clippy',['cargo','clippy','--locked','--release','--all-targets','-j2','--','-D','warnings']),('native-build',['cargo','build','--locked','--release','--bin','rogue_commander','-j2'])]
for label,command in commands:
 cmd=['nix','develop','--command',*command];start=time.monotonic()
 with (p/(label+'.log')).open('w') as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt=dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start);(p/(label+'-process.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(dict(stage=label,**receipt)),flush=True);assert res.returncode==0,label
 assert all(sha(r/n)==v for n,v in inputs.items())
assert sha(host)==before;(p/'host-profile.json').write_text(json.dumps(dict(before=before,after=sha(host)),indent=2))
