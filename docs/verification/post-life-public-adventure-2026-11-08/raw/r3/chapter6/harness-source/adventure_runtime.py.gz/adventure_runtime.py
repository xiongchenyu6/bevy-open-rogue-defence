import json,time
from campaign_runtime import main,battle_clock_from_lines
from campaign_equipment_runtime import choice_pending
from smoke_runtime import find_text,normalized

class AdventurePolicy:
    pause_budget_seconds=1200
    def __init__(self,ui):
        self.ui=ui;self.safe=False;self.fight=False;self.relic=False;self.next_check=0
        ui['report']['adventure_observations']=[]
    def click(self,row):
        _,l,t,r,b=row; call=self.ui['call'];win=self.ui['window']()
        call(['xdotool','mousemove','--window',win,str((l+r)//2),str((t+b)//2)])
        call(['xdotool','mousedown','1']);time.sleep(.15);call(['xdotool','mouseup','1'])
    def observe(self,rows,elapsed):
        if elapsed<self.next_check or choice_pending(rows):return
        clock=battle_clock_from_lines(rows)
        if clock is None:return
        target=None
        if not self.safe and clock<21*60:target='Embermaw'
        elif self.safe and not self.fight and clock<12*60:target='Tidehorn'
        if target:
            found=find_text(rows,target)
            if not found:return
            if not any('explore' in normalized(row[0]) and abs(row[2]-found[2]) < 65 and abs(row[1]-found[1]) < 80 for row in rows):return
            with self.ui['input_lock']:
                self.click(found)
                label='Take & leave' if target=='Embermaw' else 'Fight for the full reward'
                deadline=time.monotonic()+30
                while time.monotonic()<deadline:
                    current=self.ui['lines']();button=next((row for row in current if normalized(row[0]).startswith(normalized(label))),None)
                    if button:break
                else:raise AssertionError('Camp choice did not open')
                image=self.ui['shot']('camp-'+target+'-offer.png')
                self.ui['report']['adventure_observations'].append(dict(target=target,clock=clock,offer=image.name,rows=current,choice=label))
                self.click(button)
                for i in range(8):self.ui['shot'](f'camp-{target}-after-{i:02}.png');time.sleep(.1)
                if target=='Embermaw':self.safe=True
                else:self.fight=True
            self.next_check=elapsed+5
        elif self.fight and not self.relic:
            with self.ui['input_lock']:
                call=self.ui['call'];win=self.ui['window']();call(['xdotool','mousemove','--window',win,'178','44']);call(['xdotool','click','1']);time.sleep(.2)
                current=self.ui['lines']()
                if find_text(current,'ATTRIBUTES'):
                    image=self.ui['shot']('adventure-relic-attributes.png')
                    self.relic=any('glacialshatter' in normalized(x[0]) for x in current)
                    self.ui['report']['adventure_observations'].append(dict(relic=self.relic,screenshot=image.name,rows=current))
                    call(['xdotool','key','Escape'])
            self.next_check=elapsed+30
    def verify(self):
        assert self.safe and self.fight,'Both camp choices must run'
        assert self.relic,'Actual attributes must expose Glacial Shatter'

main(AdventurePolicy)
