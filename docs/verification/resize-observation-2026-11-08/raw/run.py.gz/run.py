from pathlib import Path
import subprocess,time,json
r=Path.cwd();p=r/'target/verification/resize-observation-2026-11-08';out=p/'runtime';out.mkdir()
a=json.loads((r/'target/verification/ricochet-package-2026-11-08/artifact.json').read_text());game=r/a['package_directory'];h=p/'harness'
cmd=['docker','run','--rm','--name','rogue-resize-observation-nov8','--network','none','--mount',f'type=bind,src={game},dst=/game,readonly','--mount',f'type=bind,src={h},dst=/harness,readonly','--mount',f'type=bind,src={out},dst=/verify','--env','PACKAGE_COMMIT='+a['source_commit'],'--workdir','/tmp','sha256:0d4cccee982b31492e0f7b01a50afc1a0ec710d3166dab22e02322ce64832715','python3','/harness/smoke_runtime.py']
start=time.monotonic()
try:
 with (p/'runtime.log').open('w') as log:res=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 (p/'process.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
finally:subprocess.run(['docker','stop','-t','15','rogue-resize-observation-nov8'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
raise SystemExit(res.returncode)
