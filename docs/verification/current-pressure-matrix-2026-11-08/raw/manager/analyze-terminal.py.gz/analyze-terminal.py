"""Terminal-only descriptive analysis. No simulation, tuning or population inference."""
import argparse
import csv
import itertools
import json
import pathlib
import re

EXPECTED_BINARY = 'a6099bc9afc343c6840bbcb558182dfd8a543d2d248e7f7b83704302a1a5f2da'
NAME = re.compile(r'(active|passive)-h([012])-behind-s(1|beef)-c([05])-t0', re.I)
PRESSURE = ['gate_breaks', 'exposed_secs', 'min_gate_hp', 'min_hero_hp',
            'min_alive_health_fraction', 'max_health_deficit', 'injured_secs',
            'max_hero_hp', 'hero_hp', 'deaths', 'elapsed', 'wave', 'level', 'kills']


def load(path):
    return json.loads(path.read_text())


def checkpoints(path):
    rows = []
    with path.open() as source:
        for line in source:
            if not line.startswith('{'):
                continue
            row = json.loads(line, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
            if row.get('type') == 'checkpoint':
                rows.append(row)
    return rows


def main(batch, process, destination):
    assert load(process)['returncode'] == 0, 'Require actual terminal successful manager receipt'
    summary = load(batch / 'summary.json')
    receipts = summary['cases']
    assert len(receipts) == 24
    assert summary['binary_sha256'] == EXPECTED_BINARY
    expected = set(itertools.product(['active', 'passive'], range(3), [1, 0xBEEF], [0, 5]))
    observed, results = set(), []
    for receipt in receipts:
        match = NAME.fullmatch(receipt['name'])
        assert match, receipt['name']
        policy, starter, seed, chapter = match.groups()
        starter, seed, chapter = int(starter), int(seed, 16), int(chapter)
        identity = policy, starter, seed, chapter
        assert identity not in observed
        observed.add(identity)
        assert receipt['returncode'] == 0 and not receipt['timed_out']
        assert receipt['valid'] and receipt['dimension_valid'] and not receipt['censored']
        assert receipt['binary_sha256'] == EXPECTED_BINARY
        path = batch / pathlib.Path(receipt['log']).name
        rows = checkpoints(path)
        assert rows and rows[-1]['finished'] and rows[-1] == receipt['last']
        assert len(rows) == receipt['checkpoints']
        assert all(a['frame'] < b['frame'] for a, b in zip(rows, rows[1:]))
        first = next(row for row in rows if row['elapsed'] > 0)
        last = rows[-1]
        assert first['actual_run_seed'] == (seed + 1) % (1 << 64)
        assert first['actual_hero_id'] == [2, 1, 0][starter]
        assert all(row['actual_chapter'] == chapter and row['permanent_upgrades'] == [0]*6 for row in rows)
        previous, first_cap = None, None
        heroes = []
        for row in rows:
            ranks = row['skill_ranks_by_id']
            assert len(ranks) == 32 and all(isinstance(rank, int) and rank >= 0 for rank in ranks)
            if row['actual_hero_id'] not in heroes:
                heroes.append(row['actual_hero_id'])
            if first_cap is None and any(rank >= 5 for rank in ranks):
                first_cap = [previous, row['elapsed']]
            previous = row['elapsed']
        ranks = last['skill_ranks_by_id']
        result = dict(case=receipt['name'], chapter_index=chapter, requested_starter=starter,
                      initial_hero_id=first['actual_hero_id'], observed_hero_ids=heroes,
                      final_hero_id=last['actual_hero_id'], policy=policy,
                      requested_seed=seed, actual_run_seed=first['actual_run_seed'],
                      outcome='win' if last['victory'] else 'loss', final_frame=last['frame'],
                      learned=sum(rank > 0 for rank in ranks), at_or_above_base_cap5=sum(rank >= 5 for rank in ranks),
                      stored_rank_total=sum(ranks), rank_vector=ranks,
                      first_base_cap_observation_interval=first_cap)
        result.update({key: last[key] for key in PRESSURE})
        results.append(result)
    assert observed == expected
    assert not destination.exists(), 'Refuse overwrite of analysis evidence'
    destination.mkdir(parents=True)
    grouped = []
    for chapter, policy in itertools.product([0, 5], ['active', 'passive']):
        group = [row for row in results if row['chapter_index'] == chapter and row['policy'] == policy]
        grouped.append(dict(chapter_index=chapter, policy=policy, cases=len(group),
                            victories=sum(row['outcome'] == 'win' for row in group),
                            losses=sum(row['outcome'] == 'loss' for row in group),
                            ranges={key: [min(row[key] for row in group), max(row[key] for row in group)]
                                    for key in PRESSURE + ['learned', 'at_or_above_base_cap5', 'stored_rank_total']}))
    report = dict(scope='24 terminal descriptive stationary-policy samples, synthetic chapter access and zero training; initial starter is not final class; no population win rate or causal tuning claim. Base cap5 is not UR evolution completion. First-cap intervals are checkpoint observation bounds.',
                  binary_sha256=EXPECTED_BINARY, cases=results, groups=grouped)
    (destination/'analysis.json').write_text(json.dumps(report, indent=2)+'\n')
    with (destination/'cases.csv').open('w', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    print(json.dumps(dict(valid_terminal_cases=24, groups=grouped)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('batch', type=pathlib.Path)
    parser.add_argument('process', type=pathlib.Path)
    parser.add_argument('output', type=pathlib.Path)
    args = parser.parse_args()
    main(args.batch, args.process, args.output)
