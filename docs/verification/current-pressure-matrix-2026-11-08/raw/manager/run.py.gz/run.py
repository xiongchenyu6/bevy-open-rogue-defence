from pathlib import Path
import subprocess,json,hashlib,time,os
r=Path.cwd();p=r/'target/verification/current-pressure-matrix-2026-11-08';base=r/'target/verification/ricochet-geometry-2026-11-08';f=base/'frozen'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
inputs=json.loads((base/'after/inputs.json').read_text());assert all(sha(r/n)==h for n,h in inputs.items())
pins=json.loads((base/'pair-pins.json').read_text());assert all(sha(f/n)==h for n,h in pins.items())
(p/'source-join.json').write_text(json.dumps(dict(game_source='064fe0a',current_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),compiled_inputs=inputs,frozen_pins=pins,scope='Real GamePlugin descriptive24cases,synthetic chapter access,zero permanent upgrades,stationarycard0policies,no actual earned progression or global winrate claim.'),indent=2))
cmd=['nix','develop','--command','python3',str(f/'tools/run_balance_matrix.py'),'--binary',str(f/'balance-sim'),'--batch','current-pressure-matrix-nov8','--frames','180000','--jobs','2','--case-timeout','900','--chapters','0,5','--training','0','--seeds','1,BEEF','--policies','passive,active','--starters','0,1,2','--positions','behind','--require-telemetry']
env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'};env['ROGUE_SIM_ASSET_ROOT']=str(f/'assets');start=time.monotonic()
with (p/'matrix.log').open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'process.json').write_text(json.dumps(dict(command=cmd,returncode=result.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(sha(f/n)==h for n,h in pins.items());assert all(sha(r/n)==h for n,h in inputs.items())
raise SystemExit(result.returncode)
