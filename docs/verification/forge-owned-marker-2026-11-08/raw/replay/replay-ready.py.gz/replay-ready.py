import json,sys
from pathlib import Path
sys.path.insert(0,'/work/tools/desktop')
from forge_runtime import read_recipe_materials,verify_recipe_selection,crop_text,INVENTORY_TITLE_CROP,FORGE_ACTION_CROP
p=Path('/work/target/verification/earned-forge-materials-r6-2026-11-08/forge/ready-materials.png')
materials=read_recipe_materials(p,None);title=crop_text(p,INVENTORY_TITLE_CROP,None);action=crop_text(p,FORGE_ACTION_CROP,None)
verify_recipe_selection(title,materials,action)
print(json.dumps({'retrospective_pixel_verification':'PASS','title':title,'materials':materials,'action':action,'scope':'Read original screenshot only; no game input or live crafting.'},indent=2))
