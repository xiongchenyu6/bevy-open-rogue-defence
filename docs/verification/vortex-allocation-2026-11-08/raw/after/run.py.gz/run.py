from pathlib import Path
import subprocess,time,json,hashlib,os
r=Path.cwd();p=r/'target/verification/vortex-allocation-2026-11-08/after'
inputs={str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [*r.glob('src/**/*.rs'),r/'Cargo.toml',r/'Cargo.lock']}
(p/'inputs.json').write_text(json.dumps(inputs,indent=2))
cmd=['nix','develop','--command','cargo','test','--locked','--release','--lib','vortex_','-j2','--','--nocapture','--test-threads=1']
start=time.monotonic();env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_')}
with (p/'tests.log').open('w') as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'result.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==digest for f,digest in inputs.items())
assert res.returncode == 0
cmd=['nix','develop','--command','cargo','test','--locked','--release','--lib','-j2','--','--test-threads=1']
start=time.monotonic()
with (p/'library.log').open('w') as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'library-result.json').write_text(json.dumps(dict(command=cmd,returncode=res.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==digest for f,digest in inputs.items())
raise SystemExit(res.returncode)
