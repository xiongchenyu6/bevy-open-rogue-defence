from pathlib import Path
import os,subprocess,json,time
r=Path.cwd();p=r/'target/verification/forge-reader-2026-11-08';exe=r/'target/verification/forge-materials-2026-11-08/r5/candidate-capture'
env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'}
env.update(ROGUE_CAPTURE_SAVE_FRAMES='35,215,257',ROGUE_COMMANDER_LANG='en',VK_ICD_FILENAMES='/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json')
for k in ['CAMPAIGN','TUTORIAL','AUDIO','DETAIL']:env['ROGUE_'+k+'_SAVE']=str(p/(k.lower()+'.txt'))
cmd=['nix','develop','--command',str(exe),'frames',str(p/'prism-en'),'300','crafting-1','0xC0126','1280x720'];start=time.monotonic()
with (p/'capture.log').open('w') as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'capture-result.json').write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start},indent=2)+'\n');raise SystemExit(res.returncode)
