from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path.cwd();p=r/'target/verification/picker-order-2026-11-07';f=p/'frozen';assets=r/'target/verification/full-slot-variety-2026-11-07/matched-inputs/assets'
def inputs():return {str(x.relative_to(r)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [*r.glob('src/**/*.rs'),*r.glob('assets/**/*'),r/'Cargo.toml',r/'Cargo.lock'] if x.is_file()}
a=inputs();(p/'inputs.json').write_text(json.dumps(a,indent=2));(p/'HEAD.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
for name in ['src/game/progression.rs','src/game/combat.rs','src/game/combat/picker_rng_order_tests.rs','src/bin/balance_sim.rs','src/game/resources.rs']:
 out=p/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,out)
clean={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'}
def run(name,cmd,env=None):
 t=time.monotonic()
 with (p/(name+'.log')).open('w') as out:x=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env or clean)
 (p/(name+'-result.json')).write_text(json.dumps({'command':cmd,'returncode':x.returncode,'elapsed':time.monotonic()-t}));assert inputs()==a,'source inputs drifted';print(name,'TERMINAL',x.returncode,flush=True);assert x.returncode==0
trace_test=clean|{'ROGUE_SIM_PICKER_TRACE':'1'}
run('focused',['nix','develop','--command','cargo','test','--locked','--release','--lib','real_g_draw_is_sensitive','-j2','--','--nocapture'],trace_test)
rows=[json.loads(line) for line in (p/'focused.log').read_text().splitlines() if line.startswith('{')]
assert sum(x['type']=='picker_entry' for x in rows)==2
assert sum(x['type']=='picker_exit' for x in rows)==2
(p/'focused-picker-rows.json').write_text(json.dumps(rows,indent=2))
run('library-tests',['nix','develop','--command','cargo','test','--locked','--release','--lib','-j2'])
run('clippy',['nix','develop','--command','cargo','clippy','--locked','--release','--all-targets','-j2','--','-D','warnings'])
run('bin-tests',['nix','develop','--command','cargo','test','--locked','--release','--bin','balance_sim','-j2'])
run('build',['nix','develop','--command','cargo','build','--locked','--release','--bin','balance_sim','-j2'])
exe=f/'balance-sim';shutil.copyfile(r/'target/release/balance_sim',exe);exe.chmod(0o755);(p/'binary.sha256').write_text(hashlib.sha256(exe.read_bytes()).hexdigest());(p/'inputs-after-build.json').write_text(json.dumps(inputs(),indent=2))
asset_hashes={str(x.relative_to(assets)):hashlib.sha256(x.read_bytes()).hexdigest() for x in assets.rglob('*') if x.is_file()};assert all(a['assets/'+k]==v for k,v in asset_hashes.items());(p/'asset-inputs.json').write_text(json.dumps(asset_hashes,indent=2))
env=clean|{'ROGUE_SIM_ASSET_ROOT':str(assets),'ROGUE_SIM_PICKER_TRACE':'1','RUST_LOG':'projectile_hit=trace'}
for label in ['a','b']:
 cmd=['nix','develop','--command','python3',str(f/'tools/run_balance_matrix.py'),'--binary',str(exe),'--batch','picker-trace-'+label,'--frames','180000','--jobs','1','--case-timeout','900','--chapters','0','--training','0','--seeds','1','--policies','active','--starters','1','--positions','behind','--require-telemetry']
 run('replay-'+label,cmd,env)
 folder=f/'target/verification'/('picker-trace-'+label);log=folder/'active-h1-behind-s1-c0-t0.jsonl';err=folder/'active-h1-behind-s1-c0-t0.stderr';raw=log.read_text();records=[json.loads(x) for x in raw.splitlines() if x.startswith('{')]
 assert any(x.get('type')=='picker_entry' for x in records)
 assert sum(x.get('type')=='picker_entry' for x in records)==sum(x.get('type')=='picker_exit' for x in records)
 assert 'PROJECTILE_HIT' in raw+err.read_text(), 'existing contact trace must actually be present'
 assert {str(x.relative_to(assets)):hashlib.sha256(x.read_bytes()).hexdigest() for x in assets.rglob('*') if x.is_file()}==asset_hashes
(p/'inputs-after-runs.json').write_text(json.dumps(inputs(),indent=2));print('PICKER DIAGNOSTIC TWO RUNS TERMINAL',flush=True)
