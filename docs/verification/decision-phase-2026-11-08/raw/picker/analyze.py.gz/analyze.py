from pathlib import Path
import itertools,json,re,hashlib
ROOT=Path(__file__).resolve().parent
CASE='active-h1-behind-s1-c0-t0'
folders=[ROOT/'frozen/target/verification'/('picker-trace-r2-'+x) for x in 'ab']
ansi=re.compile(r'\x1b\[[0-9;]*m')
number=re.compile(r'\b([a-z_]+)=([-+0-9.eE]+)')
def contacts(path):
 rows=[]
 for line in path.open():
  if 'PROJECTILE_HIT' not in line:continue
  text=ansi.sub('',line.rstrip());value={k:(float(v) if any(c in v for c in '.eE') else int(v)) for k,v in number.findall(text)}
  value['profile']=re.search(r'\bprofile=(.*?)\s+base_damage=',text).group(1)
  value['raw']=text;rows.append(value)
 return rows
def first_diff(a,b,omit=()):
 for index,(left,right) in enumerate(itertools.zip_longest(a,b)):
  l={k:v for k,v in left.items() if k not in omit} if left is not None else None
  r={k:v for k,v in right.items() if k not in omit} if right is not None else None
  if l!=r:return {'index':index,'fields':{k:[l.get(k),r.get(k)] for k in l.keys()|r.keys() if l.get(k)!=r.get(k)} if l is not None and r is not None else {'length':[len(a),len(b)]},'a':left,'b':right}
 return None
rows=[[json.loads(s) for s in (f/(CASE+'.jsonl')).read_text().splitlines() if s.startswith('{')] for f in folders]
picker=[[r for r in case if r.get('type') in ('picker_entry','picker_exit')] for case in rows]
contact=[contacts(f/(CASE+'.stderr')) for f in folders]
result={'scope':'Two default-feature traced runs only. Same source/binary/assets/policy; this is not the original uninstrumented pair. Identity and all recorded nonidentity fields remain separate.','json_counts':[len(x) for x in rows],'picker_counts':[len(x) for x in picker],'contact_counts':[len(x) for x in contact], 'first_json_identity_or_numeric':first_diff(*rows),'first_json_nonidentity':first_diff(*rows,omit={'root'}),'first_picker_difference':first_diff(*picker),'first_contact_identity_or_numeric':first_diff(*contact,omit={'raw'}),'first_contact_nonidentity':first_diff(*contact,omit={'raw','projectile','enemy','projectile_bits','enemy_bits'}),'outcomes':[next(x for x in reversed(case) if x.get('type')=='checkpoint') for case in rows]}
result['strict_recorded_nonidentity_match']=result['first_json_nonidentity'] is None and result['first_contact_nonidentity'] is None
result['raw_hashes']={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for folder in folders for f in folder.glob('*') if f.is_file() and f.suffix in ('.jsonl','.stderr')}
(ROOT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('json_counts','picker_counts','contact_counts','strict_recorded_nonidentity_match')},indent=2))
for key in ('first_json_nonidentity','first_picker_difference','first_contact_nonidentity'):
 value=result[key];print(key,None if value is None else {'index':value['index'],'fields':value['fields']})
