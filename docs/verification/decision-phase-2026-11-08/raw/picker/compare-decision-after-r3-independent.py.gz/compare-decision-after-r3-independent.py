import collections,hashlib,json,re
from pathlib import Path
P=Path(__file__).resolve().parent
ANSI=re.compile(r'\x1b\[[0-9;]*m')
IDS={'root','entity','projectile','enemy','projectile_bits','enemy_bits'}
def proj(x):
 if isinstance(x,dict):return {k:proj(v) for k,v in x.items() if k not in IDS}
 if isinstance(x,list):return [proj(v) for v in x]
 return x
def diff(a,b):
 out=[]
 for i in range(max(len(a),len(b))):
  x=a[i] if i<len(a) else None;y=b[i] if i<len(b) else None
  if x!=y:out.append({'index':i,'a':x,'b':y})
 return out
def read(label):
 f=P/'frozen/target/verification'/('decision-phase-after-r3-'+label)
 rows=[];contacts=[];receipts=[]
 for suffix in ('jsonl','stderr'):
  path=f/('active-h1-behind-s1-c0-t0.'+suffix);data=path.read_bytes();receipts.append({'path':str(path.relative_to(P)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
  for line in data.decode().splitlines():
   if line.startswith('{'):rows.append(json.loads(line))
   clean=ANSI.sub('',line)
   if 'PROJECTILE_HIT ' in clean:
    payload=clean.split('PROJECTILE_HIT ',1)[1];parts=list(re.finditer(r'(\w+)=',payload));fields={m.group(1):payload[m.end():parts[j+1].start() if j+1<len(parts) else len(payload)].strip() for j,m in enumerate(parts)}
    contacts.append(fields)
 return rows,contacts,receipts
A,CA,RA=read('a');B,CB,RB=read('b')
r={'scope':'This final phase-source pair only. No claim that the earlier 625-second mismatch was resolved. stdout/stderr ordering cannot establish cross-stream chronology.','identity_fields_excluded_only_in_projection':sorted(IDS),'inputs':[RA,RB],'json':{}}
for kind in sorted(set(x['type'] for x in A+B)):
 a=[x for x in A if x['type']==kind];b=[x for x in B if x['type']==kind]
 r['json'][kind]={'counts':[len(a),len(b)],'raw_differences':diff(a,b),'identity_projection_differences':diff(proj(a),proj(b))}
r['contacts']={'counts':[len(CA),len(CB)],'raw_field_differences':diff(CA,CB),'identity_projection_differences':diff(proj(CA),proj(CB)),'scope':'Raw parsed fields retain all identity and numeric/profile fields. Wall-clock logging prefixes are transport metadata and remain in original hashed logs.'}
(P/'decision-phase-after-r3-independent-comparison.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'json':{k:{'counts':v['counts'],'raw_differences':len(v['raw_differences']),'projection_differences':len(v['identity_projection_differences'])} for k,v in r['json'].items()},'contacts':{'counts':r['contacts']['counts'],'raw_differences':len(r['contacts']['raw_field_differences']),'projection_differences':len(r['contacts']['identity_projection_differences'])}},indent=2))
