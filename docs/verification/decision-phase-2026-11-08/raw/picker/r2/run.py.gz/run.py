from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path.cwd();p=r/'target/verification/picker-order-2026-11-07';out=p/'r2';f=p/'frozen';exe=f/'balance-sim';assets=r/'target/verification/full-slot-variety-2026-11-07/matched-inputs/assets'
def inputs():return {str(x.relative_to(r)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [*r.glob('src/**/*.rs'),*r.glob('assets/**/*'),r/'Cargo.toml',r/'Cargo.lock'] if x.is_file()}
a=inputs();assert a==json.loads((p/'inputs.json').read_text());(out/'inputs.json').write_text(json.dumps(a,indent=2));assert hashlib.sha256(exe.read_bytes()).hexdigest()==(p/'binary.sha256').read_text().strip()
clean={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'}
env=clean|{'ROGUE_SIM_ASSET_ROOT':str(assets),'ROGUE_SIM_PICKER_TRACE':'1','RUST_LOG':'rogue_commander::projectile_hit=trace'}
(out/'diagnostic-env.json').write_text(json.dumps({k:env[k] for k in ['ROGUE_SIM_ASSET_ROOT','ROGUE_SIM_PICKER_TRACE','RUST_LOG']},indent=2))
counts={}
for label in ['a','b']:
 batch='picker-trace-r2-'+label
 cmd=['nix','develop','--command','python3',str(f/'tools/run_balance_matrix.py'),'--binary',str(exe),'--batch',batch,'--frames','180000','--jobs','1','--case-timeout','900','--chapters','0','--training','0','--seeds','1','--policies','active','--starters','1','--positions','behind','--require-telemetry']
 t=time.monotonic()
 with (out/('replay-'+label+'.log')).open('w') as log:x=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 (out/('replay-'+label+'-result.json')).write_text(json.dumps({'command':cmd,'returncode':x.returncode,'elapsed':time.monotonic()-t}));assert inputs()==a;print('replay-'+label,'TERMINAL',x.returncode,flush=True);assert x.returncode==0
 folder=f/'target/verification'/batch;log=folder/'active-h1-behind-s1-c0-t0.jsonl';err=folder/'active-h1-behind-s1-c0-t0.stderr';raw=log.read_text();records=[json.loads(s) for s in raw.splitlines() if s.startswith('{')]
 entry=sum(s.get('type')=='picker_entry' for s in records);exit_count=sum(s.get('type')=='picker_exit' for s in records);contacts=(raw+err.read_text()).count('PROJECTILE_HIT');assert entry>0 and entry==exit_count and contacts>0
 counts[label]={'entry':entry,'exit':exit_count,'contacts':contacts};(out/'observed-counts.json').write_text(json.dumps(counts,indent=2))
assert {str(x.relative_to(assets)):hashlib.sha256(x.read_bytes()).hexdigest() for x in assets.rglob('*') if x.is_file()}==json.loads((p/'asset-inputs.json').read_text())
(out/'inputs-after-runs.json').write_text(json.dumps(inputs(),indent=2));print('CORRECT TARGET TWO RUNS TERMINAL',flush=True)
