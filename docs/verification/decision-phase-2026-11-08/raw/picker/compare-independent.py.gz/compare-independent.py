"""Read-only paired diagnostic. Retains every differing record and raw contact line."""
import argparse
import hashlib
import json
from pathlib import Path
from itertools import zip_longest


def load(path):
    data = path.read_bytes()
    rows = []
    contacts = []
    for number, line in enumerate(data.decode().splitlines(), 1):
        if line.startswith('{'):
            rows.append({'line': number, 'record': json.loads(line)})
        if 'PROJECTILE_HIT' in line:
            contacts.append({'line': number, 'raw': line})
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(),
            'rows': rows, 'contacts': contacts}


def differences(a, b):
    result = []
    for index, (left, right) in enumerate(zip_longest(a, b)):
        x = left.get('record', left) if left is not None else None
        y = right.get('record', right) if right is not None else None
        if x != y:
            keys = sorted(set(x or {}) | set(y or {}))
            result.append({'index': index, 'changed_fields': [k for k in keys if (x or {}).get(k) != (y or {}).get(k)],
                           'a': left, 'b': right})
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    runs = []
    for label in ('a', 'b'):
        folder = args.root / 'frozen/target/verification' / ('picker-trace-' + label)
        stem = folder / 'active-h1-behind-s1-c0-t0'
        runs.append({'stdout': load(stem.with_suffix('.jsonl')), 'stderr': load(stem.with_suffix('.stderr'))})
    report = {'scope': 'Diagnostic comparison only. A matching new pair does not resolve the earlier repeat mismatch.', 'runs': runs}
    for kind in ('picker_entry', 'picker_exit', 'checkpoint'):
        series = [[x for x in run['stdout']['rows'] if x['record'].get('type') == kind] for run in runs]
        report[kind] = {'counts': list(map(len, series)), 'differences': differences(*series)}
    first = report['picker_entry']['differences']
    if first:
        context = []
        for side, run in zip(('a', 'b'), runs):
            item = first[0][side]
            if item is None:
                context.append(None)
                continue
            line = item['line']
            prior = [x for x in run['stdout']['rows'] if x['line'] < line and x['record'].get('type') == 'checkpoint']
            contacts = [x for x in run['stdout']['contacts'] if x['line'] < line]
            context.append({'previous_checkpoint': prior[-1] if prior else None, 'last_stdout_contacts': contacts[-20:]})
        report['first_entry_context'] = context
    report['raw_contact_differences'] = differences(
        runs[0]['stdout']['contacts'] + runs[0]['stderr']['contacts'],
        runs[1]['stdout']['contacts'] + runs[1]['stderr']['contacts'])
    output = args.output or args.root / 'independent-comparison.json'
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: {'counts': report[k]['counts'], 'differences': len(report[k]['differences'])} for k in ('picker_entry', 'picker_exit', 'checkpoint')}))


if __name__ == '__main__':
    main()
