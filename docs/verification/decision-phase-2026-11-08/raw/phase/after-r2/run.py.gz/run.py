from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

root = Path.cwd()
output = root / 'target/verification/decision-phase-2026-11-07/after-r2'

def inputs():
    paths = [*root.glob('src/**/*.rs'), *root.glob('assets/**/*'), root / 'Cargo.toml', root / 'Cargo.lock']
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.is_file()}

before = inputs()
(output / 'inputs.json').write_text(json.dumps(before, indent=2))
for name in ['src/game/combat.rs', 'src/game/combat/decision_phase_tests.rs', 'src/game/combat/picker_rng_order_tests.rs', 'src/game/progression.rs', 'src/game/hero.rs', 'src/game/market.rs', 'src/game/trial.rs', 'src/game/skills.rs', 'src/game/bonds.rs', 'src/bin/balance_sim.rs']:
    destination = output / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, destination)
clean = {key: value for key, value in os.environ.items() if not key.startswith('ROGUE_') and key != 'RUST_LOG'}

def environment(name):
    result = dict(clean)
    for key in ['CAMPAIGN', 'TUTORIAL', 'AUDIO']:
        result['ROGUE_' + key + '_SAVE'] = str(output / (name + '-' + key.lower() + '.txt'))
    return result

def run(name, command, env=None):
    start = time.monotonic()
    with (output / (name + '.log')).open('w') as log:
        result = subprocess.run(command, env=env or environment(name), stdout=log, stderr=subprocess.STDOUT)
    receipt = {'command': command, 'returncode': result.returncode, 'elapsed': time.monotonic() - start}
    (output / (name + '-result.json')).write_text(json.dumps(receipt, indent=2))
    assert inputs() == before, 'Frozen source changed during verification'
    print(name, 'TERMINAL', result.returncode, flush=True)
    assert result.returncode == 0, name

run('focused', ['nix', 'develop', '--command', 'cargo', 'test', '--locked', '--release', '--lib', 'production_decision_phase', '-j2', '--', '--nocapture', '--test-threads=1'])
run('library-tests', ['nix', 'develop', '--command', 'cargo', 'test', '--locked', '--release', '--lib', '-j2', '--', '--test-threads=1'])
run('release-clippy', ['nix', 'develop', '--command', 'cargo', 'clippy', '--locked', '--release', '--all-targets', '-j2', '--', '-D', 'warnings'])
run('bin-tests', ['nix', 'develop', '--command', 'cargo', 'test', '--locked', '--release', '--bin', 'balance_sim', '-j2'])
run('capture-build', ['nix', 'develop', '--command', 'cargo', 'build', '--locked', '--bin', 'capture', '-j1', '--target-dir', 'target/market-visual', '--config', 'profile.dev.opt-level=0', '--config', 'profile.dev.package."*".opt-level=0', '--config', 'profile.dev.debug=0'])
capture = output / 'capture'
shutil.copyfile(root / 'target/market-visual/debug/capture', capture)
capture.chmod(0o755)
(output / 'capture-binary.sha256').write_text(hashlib.sha256(capture.read_bytes()).hexdigest())
seed_log = root / 'target/verification/full-slot-variety-2026-11-07/candidate-r9/focused.log'
seeds = dict(re.findall(r'FULL_SLOT_NATIVE_SEED rarity=(Sr|Ssr) seed=(\d+)', seed_log.read_text()))
for size, language, rarity in [('1280x720', 'en', 'Sr'), ('360x800', 'zh', 'Ssr')]:
    name = 'native-' + size + '-' + language
    env = environment(name)
    env.update(EXPECT_FULL_SLOT_VARIETY='1', ROGUE_CAPTURE_VARIETY_SEED=format(int(seeds[rarity]), 'x'), ROGUE_CAPTURE_VARIETY_RARITY=rarity, ROGUE_COMMANDER_LANG=language, ROGUE_CAPTURE_SAVE_FRAMES='100,120,159,179', VK_ICD_FILENAMES='/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json')
    run(name, ['nix', 'develop', '--command', str(capture), 'frames', str(output / name), '180', 'skill-variety', '0xC0126', size], env)
run('sim-build', ['nix', 'develop', '--command', 'cargo', 'build', '--locked', '--release', '--bin', 'balance_sim', '-j2'])
exe = output / 'balance-sim'
shutil.copyfile(root / 'target/release/balance_sim', exe)
exe.chmod(0o755)
(output / 'sim-binary.sha256').write_text(hashlib.sha256(exe.read_bytes()).hexdigest())
frozen = root / 'target/verification/picker-order-2026-11-07/frozen'
assets = root / 'target/verification/full-slot-variety-2026-11-07/matched-inputs/assets'
assert all(hashlib.sha256((assets / path.removeprefix('assets/')).read_bytes()).hexdigest() == digest for path, digest in before.items() if path.startswith('assets/'))
for label in ['a', 'b']:
    env = dict(clean)
    env.update(ROGUE_SIM_ASSET_ROOT=str(assets), ROGUE_SIM_PICKER_TRACE='1', RUST_LOG='rogue_commander::projectile_hit=trace')
    run('replay-' + label, ['nix', 'develop', '--command', 'python3', str(frozen / 'tools/run_balance_matrix.py'), '--binary', str(exe), '--batch', 'decision-phase-after-r2-' + label, '--frames', '180000', '--jobs', '1', '--case-timeout', '900', '--chapters', '0', '--training', '0', '--seeds', '1', '--policies', 'active', '--starters', '1', '--positions', 'behind', '--require-telemetry'], env)
(output / 'inputs-after.json').write_text(json.dumps(inputs(), indent=2))
print('DECISION PHASE VERIFICATION AND TWO REPLAYS TERMINAL', flush=True)
