from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path.cwd()
output = root / 'target/verification/decision-phase-2026-11-07/before-capacity'

def inputs():
    paths = [*root.glob('src/**/*.rs'), *root.glob('assets/**/*'), root / 'Cargo.toml', root / 'Cargo.lock']
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.is_file()}

before = inputs()
(output / 'inputs.json').write_text(json.dumps(before, indent=2))
for name in ['src/game/combat.rs', 'src/game/combat/decision_phase_tests.rs', 'src/game/progression.rs', 'src/game/hero.rs', 'src/game/market.rs', 'src/game/trial.rs']:
    destination = output / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, destination)
environment = {key: value for key, value in os.environ.items() if not key.startswith('ROGUE_') and key != 'RUST_LOG'}
for key in ['CAMPAIGN', 'TUTORIAL', 'AUDIO']:
    environment['ROGUE_' + key + '_SAVE'] = str(output / ('isolated-' + key.lower() + '.txt'))
command = ['nix', 'develop', '--command', 'cargo', 'test', '--locked', '--release', '--lib', 'production_decision_phase_recruitment_refreshes_capacity', '-j2', '--', '--nocapture', '--test-threads=1']
start = time.monotonic()
with (output / 'focused.log').open('w') as log:
    result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT)
receipt = {'command': command, 'returncode': result.returncode, 'elapsed': time.monotonic() - start, 'isolated_persistence': {key: value for key, value in environment.items() if key.startswith('ROGUE_')}}
(output / 'result.json').write_text(json.dumps(receipt, indent=2))
after = inputs()
(output / 'inputs-after.json').write_text(json.dumps(after, indent=2))
assert before == after, 'Frozen source changed during before test'
print(json.dumps(receipt), flush=True)
