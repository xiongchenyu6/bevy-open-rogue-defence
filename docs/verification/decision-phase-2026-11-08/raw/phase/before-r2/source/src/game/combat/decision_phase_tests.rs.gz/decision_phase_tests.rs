// These checks exercise the registered production Update schedule, including InputPlugin.
fn decision_phase_key(app: &mut App, code: KeyCode, text: &str, state: bevy::input::ButtonState) {
    let window = app
        .world_mut()
        .query_filtered::<Entity, With<Window>>()
        .single(app.world())
        .unwrap();
    app.world_mut()
        .write_message(bevy::input::keyboard::KeyboardInput {
            key_code: code,
            logical_key: bevy::input::keyboard::Key::Character(text.into()),
            state,
            text: Some(text.into()),
            repeat: false,
            window,
        });
}

fn decision_phase_app() -> App {
    let mut app = App::new();
    app.add_plugins(
        DefaultPlugins
            .set(AssetPlugin {
                file_path: format!("{}/assets", env!("CARGO_MANIFEST_DIR")),
                ..default()
            })
            .set(bevy::window::WindowPlugin {
                primary_window: Some(Window::default()),
                exit_condition: bevy::window::ExitCondition::DontExit,
                ..default()
            })
            .disable::<bevy::render::RenderPlugin>()
            .disable::<bevy::winit::WinitPlugin>()
            .disable::<bevy::audio::AudioPlugin>()
            .disable::<bevy::core_pipeline::CorePipelinePlugin>()
            .disable::<bevy::post_process::PostProcessPlugin>()
            .disable::<bevy::anti_alias::AntiAliasPlugin>()
            .disable::<bevy::sprite_render::SpriteRenderPlugin>()
            .disable::<bevy::ui_render::UiRenderPlugin>()
            .disable::<bevy::pbr::PbrPlugin>()
            .disable::<bevy::gizmos_render::GizmoRenderPlugin>()
            .disable::<bevy::render::pipelined_rendering::PipelinedRenderingPlugin>(),
    )
    .init_asset::<StandardMaterial>()
    .init_asset::<bevy::audio::AudioSource>()
    .init_asset_loader::<bevy::audio::AudioLoader>()
    .insert_resource(bevy::time::TimeUpdateStrategy::ManualDuration(
        std::time::Duration::from_secs_f64(1.0 / 60.0),
    ))
    .insert_resource(super::super::RunSeed(0xA11CE))
    .add_plugins((
        super::super::GamePlugin,
        super::super::AssetReadinessPlugin,
        super::super::OnboardingPlugin,
    ));
    app.world_mut()
        .resource_mut::<super::super::CampaignMenu>()
        .0 = false;
    app.world_mut()
        .resource_mut::<super::super::OnboardingState>()
        .dismissed = true;
    app.finish();
    app.cleanup();

    let started = std::time::Instant::now();
    loop {
        app.update();
        if app.world().resource::<super::super::AssetReadiness>().ready {
            break;
        }
        assert!(
            started.elapsed().as_secs() < 20,
            "real assets did not become ready"
        );
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    decision_phase_key(
        &mut app,
        KeyCode::Digit1,
        "1",
        bevy::input::ButtonState::Pressed,
    );
    app.update();
    assert!(app.world().resource::<super::super::SelectedHero>().locked);
    decision_phase_key(
        &mut app,
        KeyCode::Digit1,
        "1",
        bevy::input::ButtonState::Released,
    );
    app.world_mut().resource_mut::<SpawnDirector>().enabled = false;
    app.world_mut().resource_mut::<AttackClock>().0.pause();
    app.world_mut().resource_mut::<ActiveSkill>().remaining = 10_000.;
    app.world_mut()
        .run_system_once(|mut commands: Commands, mut pools: ResMut<CombatPools>| {
            pools.retire_all_projectiles(&mut commands);
        })
        .unwrap();
    app
}

#[test]
fn production_decision_phase_g_pauses_before_actual_contact() {
    let mut app = decision_phase_app();
    app.insert_resource(RunRng::from_seed(0xA11CE));
    {
        let mut session = app.world_mut().resource_mut::<GameSession>();
        session.level = 8;
        session.elapsed = 100.;
        session.gold = 80;
        session.skill_points = 0;
        session.paused = false;
        session.finished = false;
    }
    {
        let mut economy = app.world_mut().resource_mut::<super::super::SkillEconomy>();
        economy.first_free_granted = true;
        economy.level_grants = 1;
    }
    {
        let mut build = app.world_mut().resource_mut::<PlayerBuild>();
        build.skills.fill(0);
        build.skills[..6].fill(4);
    }
    let position = Vec3::new(10., 0., 0.);
    let mut enemy = test_enemy(1000.);
    enemy.elite = false;
    let target = app
        .world_mut()
        .spawn((enemy, Transform::from_translation(position)))
        .id();
    app.world_mut()
        .run_system_once(
            move |mut commands: Commands, mut pools: ResMut<CombatPools>| {
                let projectile = pools
                    .rent_projectile(
                        &mut commands,
                        Handle::default(),
                        Handle::default(),
                        Transform::from_translation(position),
                        Projectile {
                            velocity: Vec3::ZERO,
                            damage: 25.,
                            radius: 0.1,
                            remaining_hits: 0,
                            lifetime: 2.,
                        },
                    )
                    .unwrap();
                commands
                    .entity(projectile)
                    .insert(DamageProfile::PHYSICAL_ATTACK);
            },
        )
        .unwrap();
    decision_phase_key(
        &mut app,
        KeyCode::KeyG,
        "g",
        bevy::input::ButtonState::Pressed,
    );
    app.update();
    let health = app.world().get::<Enemy>(target).unwrap().hp;
    let session = app.world().resource::<GameSession>();
    let draft = app.world().resource::<super::super::DraftState>();
    println!(
        "PRODUCTION_DECISION_CONTACT hp={health} paused={} gold={} choices={:?}",
        session.paused, session.gold, draft.choices
    );
    assert!(draft.root.is_some(), "actual G must open a paid hand");
    assert!(session.paused);
    assert_eq!(session.gold, 0);
    assert_eq!(
        app.world()
            .resource::<super::super::SkillEconomy>()
            .paid_draws,
        1
    );
    assert_eq!(
        health, 1000.,
        "opening the hand must precede battle contact"
    );
    assert_eq!(
        app.world_mut()
            .query::<&Projectile>()
            .iter(app.world())
            .count(),
        1
    );
}
