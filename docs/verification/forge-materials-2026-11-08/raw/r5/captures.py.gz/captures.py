from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path.cwd();p=r/'target/verification/forge-materials-2026-11-08/r5';candidate=p/'candidate-capture'
shutil.copyfile(r/'target/market-visual/debug/capture',candidate);candidate.chmod(0o755)
(p/'candidate.sha256').write_text(hashlib.sha256(candidate.read_bytes()).hexdigest())
old=r/'target/verification/decision-phase-2026-11-07/after-r3/capture'
for stage,binary,cases in [('after',candidate,[(0,'1280x720','en'),(1,'1280x720','zh'),(0,'360x800','en'),(1,'360x800','zh'),(0,'320x667','en'),(1,'320x667','zh'),(1,'852x393','zh')])]:
 for phase,size,language in cases:
  name=f'{stage}-chain{phase}-{size}-{language}';folder=p/name;env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'}
  env.update(ROGUE_CAPTURE_SAVE_FRAMES='35,215,237,257,270,273',ROGUE_COMMANDER_LANG=language,VK_ICD_FILENAMES='/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json')
  for k in ['CAMPAIGN','TUTORIAL','AUDIO']:env['ROGUE_'+k+'_SAVE']=str(p/(name+'-'+k+'.txt'))
  cmd=['nix','develop','--command',str(binary),'frames',str(folder),'300','crafting-'+str(phase),'0xC0126',size]
  with (p/(name+'.log')).open('w') as f:
   start=time.monotonic();res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  (p/(name+'-result.json')).write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start},indent=2)+'\n');print(name,res.returncode,flush=True)
  if res.returncode:raise SystemExit(res.returncode)
