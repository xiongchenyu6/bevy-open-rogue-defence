from pathlib import Path
import subprocess,time,os,json,hashlib
r=Path.cwd();p=r/'target/verification/forge-materials-2026-11-08/r5';before=json.loads((p/'inputs.json').read_text())
for n,h in before.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h
cmd=['nix','develop','--command','cargo','test','--locked','--release','--lib','-j2','--','--test-threads=1'];env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'}
env['XDG_CONFIG_HOME']=str(p/'isolated-config')
for key in ['CAMPAIGN','TUTORIAL','AUDIO','DETAIL']:env['ROGUE_'+key+'_SAVE']=str(p/('isolated-'+key.lower()+'.txt'))
with (p/'isolated-library-tests.log').open('w') as f:
 start=time.monotonic();res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'isolated-library-tests-result.json').write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start,'preference_overrides':{k:v for k,v in env.items() if k.startswith('ROGUE_') or k == 'XDG_CONFIG_HOME'}},indent=2)+'\n')
for n,h in before.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h
raise SystemExit(res.returncode)
