from pathlib import Path
import json,subprocess,hashlib,shutil,time
r=Path.cwd();p=r/'target/verification/forge-materials-2026-11-08/r4'
def inputs():
 return {str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [*r.glob('src/**/*.rs'),*r.glob('assets/**/*'),r/'Cargo.toml',r/'Cargo.lock'] if f.is_file()}
a=inputs();(p/'inputs.json').write_text(json.dumps(a,indent=2)+'\n')
for name in ['src/game/equipment_ui.rs','src/game/equipment_ui/panel.rs','src/game/equipment_ui/materials.rs','src/game/crafting.rs','src/game/settings/entry_layout.rs','src/bin/capture/crafting.rs']:
 f=p/'source'/name;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,f)
def run(name,cmd):
 with (p/(name+'.log')).open('w') as f:
  start=time.monotonic();res=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 (p/(name+'-result.json')).write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start},indent=2)+'\n');print(name,res.returncode,flush=True);assert inputs()==a
 assert res.returncode==0,name
prefix=['nix','develop','--command','cargo'];cfg=['--locked','--bin','capture','-j1','--target-dir','target/market-visual','--config','profile.dev.opt-level=0','--config','profile.dev.package."*".opt-level=0','--config','profile.dev.debug=0']
run('capture-clippy',prefix+['clippy']+cfg+['--','-D','warnings'])
run('capture-build',prefix+['build']+cfg)
s=(p.parent/'run-captures.py').read_text().replace("p=r/'target/verification/forge-materials-2026-11-08'","p=r/'target/verification/forge-materials-2026-11-08/r4'").replace("('before',old,[(0,'1280x720','en'),(1,'360x800','zh')]),",'')
(p/'captures.py').write_text(s);run('native', ['python3',str(p/'captures.py')])
run('library-tests',prefix+['test','--locked','--release','--lib','-j2','--','--test-threads=1'])
run('release-clippy',prefix+['clippy','--locked','--release','--all-targets','-j2','--','-D','warnings'])
(p/'inputs-after.json').write_text(json.dumps(inputs(),indent=2)+'\n');print('FINAL FORGE MATERIAL PIPELINE PASS',flush=True)
