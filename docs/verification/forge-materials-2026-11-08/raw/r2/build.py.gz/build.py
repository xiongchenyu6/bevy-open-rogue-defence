from pathlib import Path
import subprocess,json,time
p=Path('target/verification/forge-materials-2026-11-08/r2')
cmd=['nix','develop','--command','cargo','build','--locked','--bin','capture','-j1','--target-dir','target/market-visual','--config','profile.dev.opt-level=0','--config','profile.dev.package."*".opt-level=0','--config','profile.dev.debug=0']
with (p/'build.log').open('w') as f:
 start=time.monotonic();res=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(p/'build-result.json').write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start},indent=2))
raise SystemExit(res.returncode)
