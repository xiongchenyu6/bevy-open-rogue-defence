import hashlib,json,pathlib,subprocess,time
root=pathlib.Path.cwd(); out=root/'target/verification/post-life-public-chapter6-2026-11-08-r7'; folder=out/'chapter6'; package=root/'target/desktop-packages-life-camera-nov8/rogue-commander-linux'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
version=json.loads((package/'version.json').read_text()); assert version['git_commit']=='df51a6cddc908e5358f2cac9fa07068f46a6a5cc'
for row in json.loads((package/'package-manifest.json').read_text())['files']: assert sha(package/row['file'])==row['sha256']
assert sha(package/'rogue_commander')==version['binary_sha256']=='8d69ed5dec8fb555e6d605eb553ce1e12f0c7c38439a8d305a69564cff05e0d9'
assert sha(folder/'state/campaign.save')=='4c9a0973fa90b3f75838ccb1999267be31ff8ff9b896a8c9b165ae5ac3e129f9'
host=pathlib.Path.home()/'.config/rogue-commander/campaign-v1.save'; before=sha(host)
pins={p.name:sha(p) for p in (folder/'harness-source').iterdir()}
image=subprocess.check_output(['docker','image','inspect','rogue-commander-linux-smoke:ubuntu24-oct8','--format','{{.Id}}'],text=True).strip()
name='rogue-post-life-public-c6-nov8-r7'
args=['docker','run','--rm','--name',name,'--network','none','--mount',f'type=bind,src={package},dst=/game,readonly','--mount',f'type=bind,src={folder},dst=/verify','--mount',f'type=bind,src={folder}/harness-source,dst=/harness,readonly']
for setting in ('CAMPAIGN_STAGE=5','CAMPAIGN_CONTINUE=1','CAMPAIGN_SPEED=1','CAMPAIGN_SEED=0xA11CE','PACKAGE_COMMIT='+version['git_commit']): args+=['--env',setting]
args+=['--workdir','/tmp',image,'python3','/harness/campaign_equipment_runtime.py']
(out/'provenance.json').write_text(json.dumps(dict(command=args,version=version,harness_files=pins,host_profile_before=before,initial_save_sha256=sha(folder/'state/campaign.save')),indent=2)+'\n')
started=time.monotonic()
try:
 with (out/'chapter6.log').open('w') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=6000)
 receipt=dict(returncode=result.returncode,elapsed=time.monotonic()-started)
except subprocess.TimeoutExpired:
 subprocess.run(['docker','stop','-t','15',name]); receipt=dict(timeout=True,elapsed=time.monotonic()-started)
receipt['host_profile_after']=sha(host);receipt['host_profile_unchanged']=sha(host)==before
receipt['harness_unchanged']=all(sha(folder/'harness-source'/n)==v for n,v in pins.items())
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
assert receipt['host_profile_unchanged'] and receipt['harness_unchanged']
raise SystemExit(receipt.get('returncode',124))
