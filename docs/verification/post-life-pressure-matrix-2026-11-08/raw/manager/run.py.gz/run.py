from pathlib import Path
import subprocess,json,hashlib,time,os,shutil
r=Path.cwd();p=r/'target/verification/post-life-pressure-matrix-2026-11-08';f=p/'frozen'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
inputs=json.loads((r/'target/verification/fallen-camera-2026-11-08/after/inputs.json').read_text());assert all(sha(r/n)==h for n,h in inputs.items())
assert json.loads((r/'target/verification/fallen-camera-2026-11-08/after/sim-build-result.json').read_text())['returncode']==0
f.mkdir();(f/'tools').mkdir();(f/'src/game').mkdir(parents=True)
for n in ['tools/run_balance_matrix.py','tools/analyze_balance.py','src/game/campaign_progress.rs']:shutil.copy2(r/n,f/n)
shutil.copytree(r/'assets',f/'assets');shutil.copy2(r/'target/release/balance_sim',f/'balance-sim');(f/'balance-sim').chmod(0o555)
pins={str(q.relative_to(f)):sha(q) for q in f.rglob('*') if q.is_file()}
(p/'source-join.json').write_text(json.dumps(dict(game_source='df51a6c',current_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),compiled_inputs=inputs,frozen_pins=pins,scope='Real GamePlugin descriptive24cases after fatal-healing/camera corrections; synthetic chapter access,zero permanent upgrades,stationarycard0policies.'),indent=2))
profile=Path.home()/'.config/rogue-commander/campaign-v1.save';profile_before=sha(profile);(p/'host-profile-before.sha256').write_text(profile_before)
cmd=['nix','develop','--command','python3',str(f/'tools/run_balance_matrix.py'),'--binary',str(f/'balance-sim'),'--batch','post-life-pressure-matrix-nov8','--frames','180000','--jobs','2','--case-timeout','900','--chapters','0,5','--training','0','--seeds','1,BEEF','--policies','passive,active','--starters','0,1,2','--positions','behind','--require-telemetry']
env={k:v for k,v in os.environ.items() if not k.startswith('ROGUE_') and k!='RUST_LOG'};env['ROGUE_SIM_ASSET_ROOT']=str(f/'assets');start=time.monotonic()
with (p/'matrix.log').open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'process.json').write_text(json.dumps(dict(command=cmd,returncode=result.returncode,elapsed=time.monotonic()-start),indent=2))
assert all(sha(f/n)==h for n,h in pins.items());assert all(sha(r/n)==h for n,h in inputs.items())
(p/'host-profile-after.sha256').write_text(sha(profile));assert sha(profile)==profile_before,'Default profile changed during isolated matrix'
raise SystemExit(result.returncode)
