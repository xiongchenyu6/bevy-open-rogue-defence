import subprocess,json,hashlib
from pathlib import Path
for relative in ['earned-forge-materials-r2-2026-11-08/forge/resume-timer-source.png','earned-forge-materials-r3-2026-11-08/forge/resume-timer-source-0015.png']:
 image=Path('/evidence')/relative
 for crop in ['90x20+20+82','100x22+18+80']:
  for method in ['gray','gray-invert','max','max-invert']:
   for scale in [300,400,600]:
    args=['convert',str(image),'-crop',crop,'+repage']
    args+=['-colorspace','Gray'] if method.startswith('gray') else ['-separate','-evaluate-sequence','max']
    if method.endswith('invert'):args+=['-negate']
    args+=['-resize',f'{scale}%','-bordercolor','white' if method.endswith('invert') else 'black','-border','20','png:-']
    pixels=subprocess.check_output(args)
    text=subprocess.run(['tesseract','stdin','stdout','-l','eng','--psm','7'],input=pixels,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout.decode().strip()
    print(json.dumps(dict(image=relative,sha256=hashlib.sha256(image.read_bytes()).hexdigest(),crop=crop,method=method,scale=scale,text=text)),flush=True)
