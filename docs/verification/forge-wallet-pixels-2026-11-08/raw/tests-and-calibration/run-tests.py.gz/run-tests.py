from pathlib import Path
import subprocess,time,json
r=Path.cwd();p=r/'target/verification/forge-wallet-pixels-2026-11-08';cmd=['docker','run','--rm','--network','none','--mount',f'type=bind,src={r},dst=/work,readonly','--workdir','/work/tools/desktop','sha256:0d4cccee982b31492e0f7b01a50afc1a0ec710d3166dab22e02322ce64832715','python3','-B','-m','unittest','test_forge_runtime','test_inventory_layout_native','test_forge_refresh','test_inventory_selection_ack','test_inventory_close','test_smoke_runtime','test_campaign_equipment_runtime']
start=time.monotonic()
with (p/'tests.log').open('w') as f:res=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(p/'tests-result.json').write_text(json.dumps({'command':cmd,'returncode':res.returncode,'elapsed':time.monotonic()-start},indent=2)+'\n');raise SystemExit(res.returncode)
