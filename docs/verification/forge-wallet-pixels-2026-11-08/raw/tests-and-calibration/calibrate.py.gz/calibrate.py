import subprocess,json
from pathlib import Path
cases=[('new117','target/verification/earned-forge-materials-r4-2026-11-08/forge/material-03-purchase-00.png'),('old17','docs/verification/hud-wallet-17-2026-11-05/after17.png'),('old111','docs/verification/hud-wallet-2026-11-05/after.png'),('old0','docs/verification/black-market-2026-11-04/en-1280x720/frame00125.png')]
for name,relative in cases:
 path='/repo/'+relative
 raw=subprocess.check_output(['convert',path,'-crop','300x14+20+166','-depth','8','rgb:-'])
 groups=[]
 for x in range(300):
  count=sum(r>175 and g>150 and r-g>10 and g-b>25 and b<195 for r,g,b in [raw[(y*300+x)*3:(y*300+x)*3+3] for y in range(14)])
  if count>=2:
   if not groups or x-groups[-1][-1]>7:groups.append([])
   groups[-1].append(x)
 left,right=groups[-1][0]+20,groups[-1][-1]+20
 for pad in [2,5]:
  crop=f'{right-left+1+pad*2}x18+{left-pad}+163'
  for scale in [300,400,600]:
   for border in [2,10,20]:
    args=['convert',path,'-crop',crop,'-resize',f'{scale}%','-colorspace','Gray','-negate','-threshold','35%','-bordercolor','white','-border',str(border),'png:-']
    raster=subprocess.check_output(args)
    texts=[subprocess.run(['tesseract','stdin','stdout','-l','eng','--psm',mode,'-c','tessedit_char_whitelist=0123456789'],input=raster,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout.decode().strip() for mode in ['7','13']]
    print(json.dumps(dict(case=name,groups=[(g[0]+20,g[-1]+20) for g in groups],bounds=[left,right],crop=crop,pad=pad,scale=scale,border=border,reads=texts)),flush=True)
