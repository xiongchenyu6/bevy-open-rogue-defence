import json,sys
from pathlib import Path
sys.path.insert(0,'/work/tools/desktop')
from smoke_runtime import ocr_screenshot
from forge_runtime import magic_penetration_from_rows
p=Path('/work/target/verification/earned-forge-attributes-r8-2026-11-08/forge');out=[]
for name in ['material-magic-penetration.png','crafted-magic-penetration.png']:
 rows=ocr_screenshot(p/name,None)
 try:value,evidence=magic_penetration_from_rows(rows);record={'name':name,'value':value,'evidence':evidence}
 except AssertionError as error:record={'name':name,'rejected':True,'error':str(error)}
 record['all_rows']=rows;out.append(record)
assert out[0]['value']==10 and out[1]['rejected'] is True
print(json.dumps(out,indent=2))
